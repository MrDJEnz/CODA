<?php

// passwords for your database 
$dbReader = "FABqSOSi7A7SNWUN";
$dbWriter = "LFhrYVHueWDWt9gT";
$dbAdmin = "9cY3AVqCJW0O4O9i";

//require(BIN_PATH . "/pass.php");
?>
